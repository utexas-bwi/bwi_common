#!/usr/bin/env python3.7
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def add_Moving_Average(df, window):
  sma = np.zeros(df.shape[0])
  for i in range(0, window):
    sma[i] = None
  for i in range(window, df.shape[0]):
    avg = 0.0
    for n in range(0, window):
      avg = avg + df.iloc[i-n]['reward']
    avg = avg/window
    sma[i] = avg
  return sma

window = 10
df = pd.read_csv("8m_contextual.txt", engine='python', sep=',')
idx = (df['type'] == 'exploit')

plt.figure(figsize=(15,10))
plt.scatter(df[~idx]['wx'], df[~idx]['wy'])
plt.savefig("explore_points.png")
plt.close()

df = df[idx]
#df['reward'] = np.clip(df['reward'],-200,0)
# Moving average of reward with window = 5

SMA = add_Moving_Average(df, window)

plt.figure(figsize=(15,10))
plt.plot(SMA, label = f"SMA {window} of reward")
plt.plot(df['E_reward'], label="Expected reward")
plt.legend()
plt.savefig(f"SMA_{window}_learning_curve.png")
plt.close()


plt.figure(figsize=(15,10))
plt.scatter(df['wx'], df['wy'])
plt.savefig("exploit_points.png")
plt.close()

